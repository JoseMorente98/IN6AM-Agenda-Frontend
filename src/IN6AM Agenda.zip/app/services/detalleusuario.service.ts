import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable() 
export class DetalleUsuarioService{
    uriDetalleUsuario = "http://localhost:3000/api/detalleUsuarios";
    constructor(private _http: Http){
    }

    getDetalleUsuario() {
        return this._http.get(this.uriDetalleUsuario)
        .map(res => {
            console.log(res.json());
        });
    }
}