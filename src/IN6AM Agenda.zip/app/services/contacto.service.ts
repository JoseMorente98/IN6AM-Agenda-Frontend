import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable() 
export class ContactoService{
    uriContacto = "http://localhost:3000/api/contactos";
    contactos:any[];
    constructor(private _http: Http){
    }

    getContactos() {
        return this._http.get(this.uriContacto)
        .map(res => {
            this.contactos = res.json();
        });
    }
}