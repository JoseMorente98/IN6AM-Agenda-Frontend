import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

//Inyectable que usaremos para el servicio
@Injectable() 
export class UsuarioService{
    //Direccion Uri de la API de NodeJS
    uriUsuario = "http://localhost:3000/api/usuarios";
    usuarios:any[];
    constructor(private _http: Http){
    }

    //Obtiene todos los usuarios
    getUsuarios() {
        return this._http.get(this.uriUsuario)
        .map(res => {
            this.usuarios = res.json();
        });
    }
}