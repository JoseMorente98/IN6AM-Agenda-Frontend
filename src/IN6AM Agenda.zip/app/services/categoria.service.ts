import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable() 
export class CategoriaService{
    uriCategoria = "http://localhost:3000/api/categorias";
    categorias:any[];
    constructor(private _http: Http){
    }

    getCategorias() {
        return this._http.get(this.uriCategoria)
        .map(res => {
            this.categorias = res.json();
        });
    }
}