import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../../../services/usuario.service';

@Component({
  selector: 'app-table-usuario',
  templateUrl: './usuario.component.html',
})
export class TableUsuarioComponent implements OnInit {
  constructor(private usuarioService:UsuarioService) { }

  ngOnInit() {
    this.usuarioService.getUsuarios().subscribe();
  }
}
