import { Component, OnInit } from '@angular/core';
import { ContactoService } from '../../../services/contacto.service';

@Component({
  selector: 'app-table-contacto',
  templateUrl: './contacto.component.html',
})
export class TableContactoComponent implements OnInit {
  constructor(private contactoService:ContactoService) { }

  ngOnInit() {
    this.contactoService.getContactos().subscribe();
  }
}
