import { Component, OnInit } from '@angular/core';
import { CategoriaService } from '../../../services/categoria.service';

@Component({
  selector: 'app-table-categoria',
  templateUrl: './categoria.component.html',
})
export class TableCategoriaComponent implements OnInit {
  constructor(private categoriaService:CategoriaService) { }

  ngOnInit() {
    this.categoriaService.getCategorias().subscribe();
  }
}
