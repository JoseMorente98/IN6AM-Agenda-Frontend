import { Component, OnInit } from '@angular/core';
import { TareaService } from '../../../services/tarea.service';

@Component({
  selector: 'app-table-tarea',
  templateUrl: './tarea.component.html',
})
export class TableTareaComponent implements OnInit {
  constructor(private tareaService:TareaService) { }

  ngOnInit() {
    this.tareaService.getTareas().subscribe();
  }
}
