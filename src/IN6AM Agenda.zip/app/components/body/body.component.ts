import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../../services/usuario.service';

//Componente que usaremos para manejar la vista
@Component({
    selector: 'app-body',
    templateUrl: './body.component.html'
})

//BodyComponent nombre de la clase
export class BodyComponent implements OnInit {
    mostrar:boolean = false;
    constructor() {}
    
    ngOnInit() {
    }
 
    frase:any = {
        mensaje: "Un gran poder requiere una gran responsabilidad",
        autor: "Ben Parker"
    }
    

    personajes:string[] = ["Dr. Octopus", "El Duende Verde", "Venom"]
}