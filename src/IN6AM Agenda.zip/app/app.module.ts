import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

//IMPORTAR COMPONENTES
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { BodyComponent } from './components/body/body.component';
import { TableUsuarioComponent } from './components/tables/usuarios/usuario.component';
import { TableCategoriaComponent } from './components/tables/categorias/categoria.component';
import { TableContactoComponent } from './components/tables/contactos/contacto.component';
import { TableTareaComponent } from './components/tables/tareas/tarea.component';

//IMPORTAR SERVICIOS
import { UsuarioService } from './services/usuario.service';
import { CategoriaService } from './services/categoria.service';
import { ContactoService } from './services/contacto.service';
import { TareaService } from './services/tarea.service';

//IMPORTAR ROUTES
import { app_routing } from './app.route';

@NgModule({
  //Declaration exportar los componentes
  declarations: [
    AppComponent,
    NavbarComponent,
    BodyComponent,
    TableUsuarioComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    app_routing
  ],
  //Providers exporta los servicios
  providers: [
    UsuarioService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
