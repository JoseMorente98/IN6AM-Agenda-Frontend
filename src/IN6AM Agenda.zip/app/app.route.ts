import { RouterModule, Routes } from '@angular/router';
import { BodyComponent } from './components/body/body.component';
import { TableUsuarioComponent } from './components/tables/usuarios/usuario.component';
import { TableCategoriaComponent } from './components/tables/categorias/categoria.component';
import { TableContactoComponent } from './components/tables/contactos/contacto.component';
import { TableTareaComponent } from './components/tables/tareas/tarea.component';
//import { HomeComponent } from './components/home/home.component';

const APP_ROUTES:Routes = [
  { path: 'body', component: BodyComponent },
  { path: 'usuarios', component: TableUsuarioComponent },
  { path: 'categorias', component: TableCategoriaComponent },
  { path: 'contactos', component: TableContactoComponent },
  { path: 'tareas', component: TableTareaComponent },
  //{ path: 'home', component: HomeComponent } ,
  { path: '**', pathMatch: 'full', redirectTo:'body'}
]

export const app_routing = RouterModule.forRoot(APP_ROUTES);
